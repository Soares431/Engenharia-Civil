package pkg_telas_login;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pkg_banco_de_dados.Conexao;
import pkg_tela_Pricinpal.TelaPrincipal;
import pkg_telas_usuarios.CadastrarUsuario;
import pkg_telas_usuarios.GerenciamentoUsuario;

import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.CardLayout;
import java.awt.Toolkit;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JPasswordField;

public class TelaLogin extends JFrame {

	private JPanel painelPrincipal;
	private JTextField caixaUsuario;
	private JPasswordField caixaSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaLogin frame = new TelaLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaLogin() {
		setUndecorated(true);
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelaLogin.class.getResource("/pkg_imagens/ECO Civil (1).png")));
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 466);
		painelPrincipal = new JPanel();
		painelPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(painelPrincipal);
		painelPrincipal.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("X");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				dispose();
				
			}
		});
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD, 20));
		lblNewLabel_2.setBounds(632, 21, 46, 35);
		painelPrincipal.add(lblNewLabel_2);
		
		JPanel painelDireito = new JPanel();
		painelDireito.setBackground(new Color(173, 216, 230));
		painelDireito.setBounds(379, 67, 311, 369);
		painelPrincipal.add(painelDireito);
		painelDireito.setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsuario.setForeground(new Color(25, 25, 112));
		lblUsuario.setFont(new Font("Times New Roman", Font.BOLD, 23));
		lblUsuario.setBounds(113, 61, 89, 34);
		painelDireito.add(lblUsuario);
		
		caixaUsuario = new JTextField();
		caixaUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		caixaUsuario.setBounds(10, 109, 291, 20);
		painelDireito.add(caixaUsuario);
		caixaUsuario.setColumns(10);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setHorizontalAlignment(SwingConstants.CENTER);
		lblSenha.setForeground(new Color(25, 25, 112));
		lblSenha.setFont(new Font("Times New Roman", Font.BOLD, 23));
		lblSenha.setBounds(113, 140, 89, 34);
		painelDireito.add(lblSenha);
		
		JLabel labelMensagem = new JLabel("Usuario ou senha incorretos");
		labelMensagem.setVisible(false);
		labelMensagem.setHorizontalAlignment(SwingConstants.CENTER);
		labelMensagem.setForeground(new Color(220, 20, 60));
		labelMensagem.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		labelMensagem.setBounds(71, 229, 189, 14);
		painelDireito.add(labelMensagem);
		
		JButton btnNewButton = new JButton("Entrar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String usuario, senha;

				usuario = caixaUsuario.getText();
			    senha = new String(caixaSenha.getPassword());

				// Passo 1 = Comando SQL
				String sql = "select * from tb_usuarios where usuario=? and senha=?";

				// Passo 2 - Preparar conex�o
				Conexao novaConexao = new Conexao();
				Connection conectar = novaConexao.getConexao();
				PreparedStatement preparar = null;
				ResultSet resultados = null;

				// Passo 3 - Tentar executar o SQL
				try {
					preparar = conectar.prepareStatement(sql);
					// Substituir as interroga��es
					preparar.setString(1, usuario);
					preparar.setString(2, senha);
					resultados = preparar.executeQuery();

					if (resultados.next()) {
						JOptionPane.showMessageDialog(null, "Bem-Vindo(a)!");

						dispose();
						TelaPrincipal t1 = new TelaPrincipal();

						t1.setVisible(true);
						t1.setLocationRelativeTo(null);
					} else {
						labelMensagem.setVisible(true);
					}

				} catch (Exception erro) {
					JOptionPane.showMessageDialog(null, "Usuario ou senha incorreto");
					System.out.println(erro.getMessage());
				}
				
			}
		});
		btnNewButton.setBackground(new Color(47, 79, 79));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Segoe UI", Font.BOLD, 20));
		btnNewButton.setBounds(92, 254, 144, 35);
		painelDireito.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(10, 5, 122, 45);
		painelDireito.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 25));
		
		
		
		JLabel lblNewLabel_1_1 = new JLabel(" N\u00E3o possui Cadastro?  Clique aqui!");
		lblNewLabel_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				CadastrarUsuario t1 = new CadastrarUsuario();

				t1.setVisible(true);
				t1.setLocationRelativeTo(null);
			}
		});
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1.setForeground(new Color(148, 0, 211));
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_1.setBounds(48, 300, 237, 14);
		painelDireito.add(lblNewLabel_1_1);
		
		caixaSenha = new JPasswordField();
		caixaSenha.setHorizontalAlignment(SwingConstants.CENTER);
		caixaSenha.setBounds(10, 185, 291, 20);
		painelDireito.add(caixaSenha);
		
		JLabel Fundo = new JLabel("New label");
		Fundo.setBackground(new Color(0, 128, 128));
		Fundo.setBounds(0, 0, 700, 466);
		Fundo.setIcon(new ImageIcon(TelaLogin.class.getResource("/pkg_imagens/fundo.jpg")));
		painelPrincipal.add(Fundo);
	}
}
