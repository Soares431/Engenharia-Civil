package pkg_banco_de_dados;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class ConsultarID {
	

 
	public String fazerConsulta(String nome) {
		//Passo 1
		String sql = "SELECT * FROM tb_engenheiro where nome_completo=?";
		String id = "";
		//Passo 2
		Conexao novaConexao = new Conexao();
		Connection conectar = novaConexao.getConexao();
		PreparedStatement preparar = null;
		ResultSet resultados = null;
		
		//passo 3 
		try {
			preparar = conectar.prepareStatement(sql);
			preparar.setString(1, nome);
			
			resultados = preparar.executeQuery();
			resultados.next();
			
			id = resultados.getString("id_engenheiro");
			
			
			
			
			
		}catch(Exception erro ) {
			JOptionPane.showMessageDialog(null, "Falha ao tentar consultar ID_engenheiro");
			System.out.println(erro.getMessage());
		}
		
		return id;
		
		
		
		
	}
	
	
}
