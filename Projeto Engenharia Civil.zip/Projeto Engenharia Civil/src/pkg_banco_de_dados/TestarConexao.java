package pkg_banco_de_dados;

public class TestarConexao {
	
	public static void main(String[] args) {
		Conexao testar = new Conexao();
		
	}

}
