package pkg_telas_usuarios;

import java.awt.EventQueue;



import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import pkg_banco_de_dados.Conexao;

import javax.swing.SpringLayout;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GerenciamentoUsuario extends JFrame {

	private JPanel painelPrincipal;
	private JTable table;
	private JTextField caixaID;
	private JTextField caixaNome;
	private JTextField caixaEmail;
	private JTextField caixaUsuario;
	private JPasswordField caixaSenha;
	DefaultTableModel modelo = new DefaultTableModel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GerenciamentoUsuario frame = new GerenciamentoUsuario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ParseException 
	 */
	public GerenciamentoUsuario() {
		setTitle("ECO Civil - Gerenciamento de Usuarios");
		setIconImage(Toolkit.getDefaultToolkit().getImage(GerenciamentoUsuario.class.getResource("/pkg_imagens/ECO Civil (1).png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 822, 593);
		painelPrincipal = new JPanel();
		painelPrincipal.setBackground(new Color(240, 255, 255));
		painelPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(painelPrincipal);
		SpringLayout sl_painelPrincipal = new SpringLayout();
		painelPrincipal.setLayout(sl_painelPrincipal);
		
		JPanel painelEsquerdo = new JPanel();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, painelEsquerdo, -5, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, painelEsquerdo, 5, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, painelEsquerdo, 585, SpringLayout.WEST, painelPrincipal);
		painelEsquerdo.setBackground(new Color(240, 255, 255));
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, painelEsquerdo, -5, SpringLayout.WEST, painelPrincipal);
		painelPrincipal.add(painelEsquerdo);
		
		JScrollPane scrollPane = new JScrollPane();
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, scrollPane, 15, SpringLayout.EAST, painelEsquerdo);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, scrollPane, -30, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, scrollPane, -20, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(scrollPane);
		
		
		JPanel painelMeioD = new JPanel();
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, painelMeioD, 589, SpringLayout.WEST, painelEsquerdo);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, scrollPane, 66, SpringLayout.NORTH, painelMeioD);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, painelMeioD, 43, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, painelMeioD, 85, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, painelMeioD, 5, SpringLayout.EAST, painelPrincipal);
		painelMeioD.setBackground(new Color(0, 139, 139));
		SpringLayout sl_painelEsquerdo = new SpringLayout();
		painelEsquerdo.setLayout(sl_painelEsquerdo);
		
		JPanel painelMeioE = new JPanel();
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, painelMeioE, 26, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, painelMeioE, 0, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, painelMeioE, 115, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, painelMeioE, 590, SpringLayout.WEST, painelEsquerdo);
		painelMeioE.setBackground(new Color(32, 178, 170));
		painelEsquerdo.add(painelMeioE);
		
		JLabel labelID = new JLabel("ID");
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, labelID, 20, SpringLayout.SOUTH, painelMeioE);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, labelID, 30, SpringLayout.WEST, painelEsquerdo);
		painelMeioE.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("GERENCIAMENTO DE USUARIOS");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Footlight MT Light", Font.BOLD, 36));
		lblNewLabel.setBounds(0, 25, 590, 41);
		painelMeioE.add(lblNewLabel);
		labelID.setForeground(new Color(47, 79, 79));
		labelID.setFont(new Font("Tahoma", Font.BOLD, 17));
		painelEsquerdo.add(labelID);
		
	    //ImageIcon foto = new ImageIcon (TelaPrincipal.class.getResource("/pacote_imagens/ECO Civil (1).png"));
		
		caixaID = new JTextField();
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, caixaID, 23, SpringLayout.SOUTH, painelMeioE);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, caixaID, 4, SpringLayout.EAST, labelID);
		painelEsquerdo.add(caixaID);
		caixaID.setColumns(10);
		
		JLabel labelNome = new JLabel("NOME COMPLETO");
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, caixaID, -16, SpringLayout.NORTH, labelNome);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, labelNome, 149, SpringLayout.WEST, labelID);
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, labelNome, 175, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, labelNome, 206, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, labelNome, 0, SpringLayout.WEST, labelID);
		labelNome.setForeground(new Color(47, 79, 79));
		labelNome.setFont(new Font("Tahoma", Font.BOLD, 17));
		painelEsquerdo.add(labelNome);
		
		caixaNome = new JTextField();
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, caixaNome, 68, SpringLayout.SOUTH, painelMeioE);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, caixaNome, 6, SpringLayout.EAST, labelNome);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, caixaNome, 355, SpringLayout.EAST, labelNome);
		painelEsquerdo.add(caixaNome);
		caixaNome.setColumns(10);
		
		JLabel labelData = new JLabel("DATA DE NASCIMENTO");
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, labelData, 224, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, labelData, 30, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, labelData, 226, SpringLayout.WEST, painelEsquerdo);
		labelData.setForeground(new Color(47, 79, 79));
		labelData.setFont(new Font("Tahoma", Font.BOLD, 17));
		painelEsquerdo.add(labelData);
		
		MaskFormatter mascaraData  = new MaskFormatter();
		try {
			mascaraData = new MaskFormatter("##/##/####");
		} catch (ParseException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		
		JFormattedTextField caixaData = new JFormattedTextField(mascaraData);
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, caixaData, 24, SpringLayout.SOUTH, caixaNome);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, caixaData, 232, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, caixaData, 371, SpringLayout.WEST, painelEsquerdo);
		painelEsquerdo.add(caixaData);
		
		JLabel labelCPF = new JLabel("CPF");
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, labelCPF, 20, SpringLayout.SOUTH, labelData);
		labelCPF.setForeground(new Color(47, 79, 79));
		labelCPF.setFont(new Font("Tahoma", Font.BOLD, 17));
		painelEsquerdo.add(labelCPF);
		
		MaskFormatter mascaraCpf  = new MaskFormatter();
		try {
			mascaraCpf = new MaskFormatter("###.###.###-##");
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		JFormattedTextField caixaCPF = new JFormattedTextField(mascaraCpf);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, labelCPF, -6, SpringLayout.WEST, caixaCPF);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, caixaCPF, 207, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, caixaCPF, 68, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, caixaCPF, 3, SpringLayout.NORTH, labelCPF);
		painelEsquerdo.add(caixaCPF);
		
		JLabel labelEmail = new JLabel("E-MAIL");
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, labelCPF, -16, SpringLayout.NORTH, labelEmail);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, labelEmail, 30, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, labelEmail, 92, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, labelEmail, 333, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, labelEmail, 302, SpringLayout.NORTH, painelEsquerdo);
		labelEmail.setForeground(new Color(47, 79, 79));
		labelEmail.setFont(new Font("Tahoma", Font.BOLD, 17));
		painelEsquerdo.add(labelEmail);
		
		caixaEmail = new JTextField();
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, caixaEmail, 99, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, caixaEmail, 310, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, caixaEmail, 347, SpringLayout.WEST, painelEsquerdo);
		painelEsquerdo.add(caixaEmail);
		caixaEmail.setColumns(10);
		
		JLabel labelPerfil = new JLabel("PERFIL DE ACESSO");
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, labelPerfil, 16, SpringLayout.SOUTH, labelEmail);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, labelPerfil, 30, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, labelPerfil, 37, SpringLayout.SOUTH, labelEmail);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, labelPerfil, 192, SpringLayout.WEST, painelEsquerdo);
		labelPerfil.setForeground(new Color(47, 79, 79));
		labelPerfil.setFont(new Font("Tahoma", Font.BOLD, 17));
		painelEsquerdo.add(labelPerfil);
		
		JComboBox comboPerfil = new JComboBox();
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, comboPerfil, 350, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, comboPerfil, 198, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, comboPerfil, 391, SpringLayout.WEST, painelEsquerdo);
		comboPerfil.setBackground(new Color(255, 255, 255));
		painelEsquerdo.add(comboPerfil);
		
		comboPerfil.addItem("Selecione");
		comboPerfil.addItem("Adminstrador");
		comboPerfil.addItem("Estagiario(a)");
		comboPerfil.addItem("Temporario(a)");
		comboPerfil.addItem("Engenheiro(a)");
		comboPerfil.addItem("Operador de Suporte");
		comboPerfil.addItem("Gerente de Projetos");
		comboPerfil.addItem("Projetista");
		
		JLabel labelUsuario = new JLabel("USUARIOS");
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, labelUsuario, 22, SpringLayout.SOUTH, labelPerfil);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, labelUsuario, 30, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, labelUsuario, 43, SpringLayout.SOUTH, labelPerfil);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, labelUsuario, 123, SpringLayout.WEST, painelEsquerdo);
		labelUsuario.setForeground(new Color(47, 79, 79));
		labelUsuario.setFont(new Font("Tahoma", Font.BOLD, 17));
		painelEsquerdo.add(labelUsuario);
		
		caixaUsuario = new JTextField();
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, caixaUsuario, 130, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, caixaUsuario, 25, SpringLayout.SOUTH, labelPerfil);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, caixaUsuario, 45, SpringLayout.SOUTH, labelPerfil);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, caixaUsuario, 333, SpringLayout.WEST, painelEsquerdo);
		painelEsquerdo.add(caixaUsuario);
		caixaUsuario.setColumns(10);
		
		JLabel labelSenha = new JLabel("SENHA");
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, labelSenha, 20, SpringLayout.SOUTH, labelUsuario);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, labelSenha, 30, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, labelSenha, 41, SpringLayout.SOUTH, labelUsuario);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, labelSenha, 89, SpringLayout.WEST, painelEsquerdo);
		labelSenha.setForeground(new Color(47, 79, 79));
		labelSenha.setFont(new Font("Tahoma", Font.BOLD, 17));
		painelEsquerdo.add(labelSenha);
		
		caixaSenha = new JPasswordField();
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, caixaSenha, 21, SpringLayout.SOUTH, caixaUsuario);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, caixaSenha, 100, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, caixaSenha, 41, SpringLayout.SOUTH, caixaUsuario);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, caixaSenha, 322, SpringLayout.WEST, painelEsquerdo);
		painelEsquerdo.add(caixaSenha);
		
		JButton btnNewButton = new JButton("CADASTRAR");
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, btnNewButton, 30, SpringLayout.WEST, painelEsquerdo);
		btnNewButton.setBorder(null);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				  String nome_completo, data_nascimento, cpf, email, perfil_acesso, usuario, senha;
					
				    nome_completo = caixaNome.getText();
				    data_nascimento = caixaData.getText();
					cpf = caixaCPF.getText();
					email = caixaEmail.getText();
					perfil_acesso = comboPerfil.getSelectedItem().toString();
					usuario = caixaUsuario.getText();
					senha = new String(caixaSenha.getPassword());
					
					String sql = "INSERT INTO tb_usuarios (nome_completo, data_nascimento, cpf, email, perfil_acesso, usuario, senha) values (?, ?, ?, ?, ?, ?, ?)";
					
					Conexao novaConexao = new Conexao();
					Connection conectar = novaConexao.getConexao();
					PreparedStatement preparar = null;
					ResultSet resultado = null;
					
					try {
						preparar = conectar.prepareStatement(sql);
						preparar.setString(1, nome_completo);
						preparar.setString(2, data_nascimento);
						preparar.setString(3, cpf);
						preparar.setString(4, email);
						preparar.setString(5, perfil_acesso);
						preparar.setString(6, usuario);
						preparar.setString(7, senha);
						preparar.execute();
						JOptionPane.showMessageDialog(null, "Cadastrado com Sucesso!");
						dispose();
						
						
					}catch(Exception erro) {
						JOptionPane.showMessageDialog(null, "Falha ao Cadastrar");
						System.err.println(erro.getMessage());
					}
					dispose();				
					try {
						GerenciamentoUsuario g1 = new GerenciamentoUsuario();
						g1.setVisible(true);
						g1.setLocationRelativeTo(null);
					} catch (Exception e1) {
						
					}
				
			}
		});
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, btnNewButton, -81, SpringLayout.SOUTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, btnNewButton, -35, SpringLayout.SOUTH, painelEsquerdo);
		btnNewButton.setBackground(new Color(102, 205, 170));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		painelEsquerdo.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("SALVAR ALTERA\u00C7\u00D5ES");
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, btnNewButton_1, 210, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, btnNewButton, -31, SpringLayout.WEST, btnNewButton_1);
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
               String id_usuario, nome_completo, data_nascimento, cpf, email, perfil_acesso, usuario, senha;
			
				
               id_usuario = caixaID.getText();
				nome_completo = caixaNome.getText();
				cpf = caixaCPF.getText();
				email = caixaEmail.getText();
				usuario = caixaUsuario.getText();
				data_nascimento = caixaData.getText();
				senha = new String(caixaSenha.getPassword());
				perfil_acesso = comboPerfil.getSelectedItem().toString();
				
				//Passo 1 - Comando SQL
				
				String sql = "UPDATE tb_usuarios SET nome_completo=?,"
						+ "data_nascimento=?, cpf=?, email=?, perfil_acesso=?, usuario=?, senha=? WHERE id_usuario=?";			
				
				//Passo 2 - Preparar a conexão
				Conexao novaConexao = new Conexao();
				Connection conectar = novaConexao.getConexao();
				PreparedStatement preparar = null;
				ResultSet resultados = null;
				
				//Passo 3 - Tentar executar o SQL
				try {
					preparar = conectar.prepareStatement(sql);
					preparar.setString(1, nome_completo);
					preparar.setString(2, data_nascimento);
					preparar.setString(3, cpf);
					preparar.setString(4, email);
					preparar.setString(5, perfil_acesso);
					preparar.setString(6, usuario);
					preparar.setString(7, senha);
					preparar.setString(8, id_usuario);
					
					preparar.execute();
					JOptionPane.showMessageDialog(null, 
							"Atualizado com sucesso");
					dispose();
					GerenciamentoUsuario g1 = new GerenciamentoUsuario();
					g1.setVisible(true);
					g1.setLocationRelativeTo(null);
					
				}catch(Exception erro) {
					System.err.println("Falha ao atualizar");
					System.err.println(erro.getMessage());
				}
			}
		});
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, btnNewButton_1, -81, SpringLayout.SOUTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, btnNewButton_1, -35, SpringLayout.SOUTH, painelEsquerdo);
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setBackground(new Color(102, 205, 170));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		painelEsquerdo.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("EXCLUIR");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				  String id_usuario = caixaID.getText();
					
					String sql = "DELETE FROM tb_usuarios where id_usuario=?";
					
					Conexao novaConexao = new Conexao();
					Connection conectar = novaConexao.getConexao();
					PreparedStatement preparar = null;
					ResultSet resultado = null;
					
					try {
						int opcaoEscolhida = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir?");
						
						if(opcaoEscolhida == 0) {
						
							preparar = conectar.prepareStatement(sql);
							preparar.setString(1, id_usuario);
							preparar.execute();
							JOptionPane.showMessageDialog(null, "Cadastro deletado com Sucesso!");
							dispose();
							
							GerenciamentoUsuario g1 = new GerenciamentoUsuario();
							g1.setVisible(true);
							g1.setLocationRelativeTo(null);
						}
						
					}catch(Exception erro) {
						JOptionPane.showMessageDialog(null, "Falha ao Deletar");
						System.err.println(erro.getMessage());
					}
				
			}
		});
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, btnNewButton_1, -27, SpringLayout.WEST, btnNewButton_2);
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, btnNewButton_2, -81, SpringLayout.SOUTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, btnNewButton_2, -35, SpringLayout.SOUTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, btnNewButton_2, 418, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, btnNewButton_2, -10, SpringLayout.EAST, painelEsquerdo);
		btnNewButton_2.setBorder(null);
		btnNewButton_2.setBackground(new Color(102, 205, 170));
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		painelEsquerdo.add(btnNewButton_2);
		painelPrincipal.add(painelMeioD);
		
	
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int numeroLinha;
				//Esse comando descobre qual linha está selecionada
				numeroLinha = table.getSelectedRow();
				
				String id_usuario, nome_completo, data_nascimento, cpf, email, perfil_acesso, usuario, senha;
					
				
				//Esses comando capturam os dados da linha selecionada
				id_usuario = modelo.getValueAt(numeroLinha, 0).toString(); 
				nome_completo = modelo.getValueAt(numeroLinha, 1).toString();
				data_nascimento = modelo.getValueAt(numeroLinha, 2).toString();
				cpf = modelo.getValueAt(numeroLinha, 3).toString();
				email = modelo.getValueAt(numeroLinha, 4).toString();
				perfil_acesso = modelo.getValueAt(numeroLinha, 5).toString();
				usuario = modelo.getValueAt(numeroLinha, 6).toString();
				senha = modelo.getValueAt(numeroLinha, 7).toString();
				
				//Esses comandos colocam os texto dentro caixas de textos
				caixaID.setText(id_usuario);
				caixaNome.setText(nome_completo);
				caixaData.setText(data_nascimento);
				caixaCPF.setText(cpf);
				caixaEmail.setText(email);
				caixaUsuario.setText(usuario);
				comboPerfil.setSelectedItem(perfil_acesso);
				caixaSenha.setText(senha);
			
			}
		});
		scrollPane.setViewportView(table);
		
		Object[] titulos = { "ID", "NOME COMPLETO", "DATA DE NASCIMENTO", "CPF", "E-MAIL", "PERFIL DE ACESSO", "USUARIO", "SENHA"};
		modelo.setColumnIdentifiers(titulos);

		Object[] linhas = new Object[8];

		table.setModel(modelo);
		
	
		Conexao novaConexao = new Conexao();
		Connection conectar = novaConexao.getConexao();
		PreparedStatement preparar = null;
		ResultSet resultado = null;
		
		try {
			String sql = "SELECT * FROM tb_usuarios";
			preparar = conectar.prepareStatement(sql);
			resultado = preparar.executeQuery();

		} catch (Exception erro) {
			JOptionPane.showMessageDialog(null, "Falha ao Consultar");
			System.err.println(erro.getMessage());

		}
		
		try {
			
			while(resultado.next()) {
				linhas[0] = resultado.getString("id_usuario");
				linhas[1] = resultado.getString("nome_completo");
				linhas[2] = resultado.getString("data_nascimento");
				linhas[3] = resultado.getString("cpf");
				linhas[4] = resultado.getString("email");
				linhas[5] = resultado.getString("perfil_acesso");
				linhas[6] = resultado.getString("usuario");
				linhas[7] = resultado.getString("senha");
	
				
				((DefaultTableModel) modelo).addRow(linhas);
			}
			
		}catch (Exception erro) {
			JOptionPane.showMessageDialog(null, "Falha ao mostrar os resultados");
			System.err.println(erro.getMessage());
		}
		JButton btnNewButton_3 = new JButton("FECHA");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setBackground(new Color(220, 20, 60));
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, btnNewButton_3, 10, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, btnNewButton_3, 0, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(btnNewButton_3);
		
		
	}
}
