package pkg_telas_usuarios;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;


import pkg_banco_de_dados.Conexao;

import java.awt.Color;
import javax.swing.SpringLayout;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class TelaUsuario extends JFrame {

	private JPanel painel;
	private JTable table;
	DefaultTableModel modelo = new DefaultTableModel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaUsuario frame = new TelaUsuario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaUsuario() {
		setTitle("ECO Civil - Usuarios Cadastrados");
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelaUsuario.class.getResource("/pkg_imagens/ECO Civil (1).png")));
		setBackground(new Color(255, 255, 255));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 694, 352);
		painel = new JPanel();
		painel.setBackground(new Color(72, 209, 204));
		painel.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		painel.setBackground(new Color(112, 224, 224));

		setContentPane(painel);
		SpringLayout sl_painel = new SpringLayout();
		painel.setLayout(sl_painel);
		
		JScrollPane scrollPane = new JScrollPane();
		sl_painel.putConstraint(SpringLayout.NORTH, scrollPane, 120, SpringLayout.NORTH, painel);
		sl_painel.putConstraint(SpringLayout.WEST, scrollPane, 85, SpringLayout.WEST, painel);
		sl_painel.putConstraint(SpringLayout.SOUTH, scrollPane, -55, SpringLayout.SOUTH, painel);
		sl_painel.putConstraint(SpringLayout.EAST, scrollPane, -85, SpringLayout.EAST, painel);
		painel.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
				
		});
		scrollPane.setViewportView(table);
		
		Object[] titulos = { "ID", "NOME COMPLETO", "DATA DE NASCIMENTO", "CPF", "E-MAIL", "PERFIL DE ACESSO", "USUARIO"};
		modelo.setColumnIdentifiers(titulos);

		Object[] linhas = new Object[7];

		table.setModel(modelo);
		
		JPanel panel = new JPanel();
		sl_painel.putConstraint(SpringLayout.SOUTH, panel, 88, SpringLayout.NORTH, painel);
		sl_painel.putConstraint(SpringLayout.EAST, panel, 5, SpringLayout.EAST, painel);
		panel.setBackground(new Color(32, 178, 170));
		sl_painel.putConstraint(SpringLayout.NORTH, panel, 10, SpringLayout.NORTH, painel);
		sl_painel.putConstraint(SpringLayout.WEST, panel, -5, SpringLayout.WEST, painel);
		painel.add(panel);
		SpringLayout sl_panel = new SpringLayout();
		panel.setLayout(sl_panel);
		
		JLabel lblNewLabel = new JLabel("Tela Usuarios ");
		sl_panel.putConstraint(SpringLayout.NORTH, lblNewLabel, 10, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.WEST, lblNewLabel, 164, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, lblNewLabel, -10, SpringLayout.SOUTH, panel);
		sl_panel.putConstraint(SpringLayout.EAST, lblNewLabel, -151, SpringLayout.EAST, panel);
		lblNewLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Footlight MT Light", Font.BOLD, 51));
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("FECHA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(220, 20, 60));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		sl_painel.putConstraint(SpringLayout.SOUTH, btnNewButton, 0, SpringLayout.SOUTH, painel);
		sl_painel.putConstraint(SpringLayout.EAST, btnNewButton, -10, SpringLayout.EAST, painel);
		painel.add(btnNewButton);
		
		Conexao novaConexao = new Conexao();
		Connection conectar = novaConexao.getConexao();
		PreparedStatement preparar = null;
		ResultSet resultado = null;
		
		try {
			String sql = "SELECT * FROM tb_usuarios";
			preparar = conectar.prepareStatement(sql);
			resultado = preparar.executeQuery();

		} catch (Exception erro) {
			JOptionPane.showMessageDialog(null, "Falha ao Consultar");
			System.err.println(erro.getMessage());

		}
		
		try {
			
			while(resultado.next()) {
				linhas[0] = resultado.getString("id_usuario");
				linhas[1] = resultado.getString("nome_completo");
				linhas[2] = resultado.getString("data_nascimento");
				linhas[3] = resultado.getString("cpf");
				linhas[4] = resultado.getString("email");
				linhas[5] = resultado.getString("perfil_acesso");
				linhas[6] = resultado.getString("usuario");
				
				((DefaultTableModel) modelo).addRow(linhas);
			}
			
		}catch (Exception erro) {
			JOptionPane.showMessageDialog(null, "Falha ao mostrar os resultados");
			System.err.println(erro.getMessage());
		}
		
	}
}
