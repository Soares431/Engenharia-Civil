package pkg_telas_Engenheiros;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import pkg_banco_de_dados.Conexao;

import java.awt.Color;
import javax.swing.SpringLayout;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class telaEngenheiros extends JFrame {

	private JPanel painelPrincipal;
	private JTable tabelaEngenheiros;
	DefaultTableModel modelo = new DefaultTableModel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaEngenheiros frame = new telaEngenheiros();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaEngenheiros() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(telaEngenheiros.class.getResource("/pkg_imagens/ECO Civil (1).png")));
		setTitle("ECO Civil - Engenherios");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 597, 410);
		painelPrincipal = new JPanel();
		painelPrincipal.setBackground(new Color(175, 238, 238));
		painelPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(painelPrincipal);
		SpringLayout sl_painelPrincipal = new SpringLayout();
		painelPrincipal.setLayout(sl_painelPrincipal);
		
		JScrollPane scrollPane = new JScrollPane();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, scrollPane, 40, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, scrollPane, 40, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, scrollPane, -40, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, scrollPane, -40, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(scrollPane);
		
		tabelaEngenheiros = new JTable();
		tabelaEngenheiros.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String id, nome, area, cpf, rg, cidade, uf, fone, email, resumo;
				
				int numeroLinha = 0;
				numeroLinha = tabelaEngenheiros.getSelectedRow();

				id = modelo.getValueAt(numeroLinha, 0).toString();
				nome = modelo.getValueAt(numeroLinha, 1).toString();
				area = modelo.getValueAt(numeroLinha, 2).toString();
				cpf = modelo.getValueAt(numeroLinha, 3).toString();
				rg = modelo.getValueAt(numeroLinha, 4).toString();
				cidade = modelo.getValueAt(numeroLinha, 5).toString();
				uf = modelo.getValueAt(numeroLinha, 6).toString();
				fone = modelo.getValueAt(numeroLinha, 7).toString();
				email = modelo.getValueAt(numeroLinha, 8).toString();
				resumo = modelo.getValueAt(numeroLinha, 9).toString();
				
			}
		});
		scrollPane.setViewportView(tabelaEngenheiros);
		
		Object[] titulos = { "ID", " NOME ", " �REAS ", " CPF ", " RG ", " CIDADE ", "UF", " TELEFONE ", "E-MAIL",
		"DECRI��O DO FUNCIONARIO    " };
		modelo.setColumnIdentifiers(titulos);

		Object[] linhas = new Object[10];
		//(nome_completo, area, cpf, rg, cidade, uf, fone,email, resumo)

		tabelaEngenheiros.setModel(modelo);
		
		String sql = "SELECT * FROM tb_engenheiro";
		
		//Passo 2 - Preparar a conex�o
		Conexao novaConexao = new Conexao();
		Connection conectar = novaConexao.getConexao();
		PreparedStatement preparar = null;
		ResultSet resultados = null;
		
		//Passo 3 - tentar executar o SQL
		try {
			preparar = conectar.prepareStatement(sql);
			resultados = preparar.executeQuery();
			
		}catch(Exception erro) {
			JOptionPane.showMessageDialog(null, "Falha ao consultar");
			System.out.println(erro.getMessage());
		}
		
		//Passo 4 - Tentar mostrar os resultados
		try {
			while(resultados.next()) {
				linhas[0] = resultados.getString("id_engenheiro");
				linhas[1] = resultados.getString("nome_completo");
				linhas[2] = resultados.getString("area");
				linhas[3] = resultados.getString("cpf");
				linhas[4] = resultados.getString("rg");
				linhas[5] = resultados.getString("cidade");
				linhas[6] = resultados.getString("uf");
				linhas[7] = resultados.getString("fone");
				linhas[8] = resultados.getString("email");
				linhas[9] = resultados.getString("resumo");
				modelo.addRow(linhas);
				
			}
		}catch(Exception erro) {
			JOptionPane.showMessageDialog(null, 
					"Falha ao mostrar os resultados");
			System.out.println(erro.getMessage());
		}
		
		JButton btnNewButton = new JButton("FECHA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(220, 20, 60));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, btnNewButton, 0, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, btnNewButton, 0, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(btnNewButton);
	}
}
