package pkg_telas_Engenheiros;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import pkg_banco_de_dados.Conexao;

import javax.swing.SpringLayout;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.SwingConstants;
import java.awt.ComponentOrientation;
import javax.swing.JCheckBoxMenuItem;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Window.Type;
import java.awt.Frame;
import java.awt.SystemColor;
import java.awt.Insets;

public class TelaDeEngenheiros extends JFrame {

	private JPanel painelPrincipal;
	DefaultTableModel modelo = new DefaultTableModel();
	private JTable tabelaEngenheiros;
	String id_eng;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaDeEngenheiros frame = new TelaDeEngenheiros();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaDeEngenheiros() {
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setType(Type.POPUP);
		setForeground(Color.BLACK);
		setFont(new Font("Agency FB", Font.BOLD, 25));
		setTitle("ECO Civil -  Gerenciamento de Engenheiros");
		setIconImage(
				Toolkit.getDefaultToolkit().getImage(TelaDeEngenheiros.class.getResource("/pkg_imagens/ECO Civil (1).png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1026, 744);
		painelPrincipal = new JPanel();
		painelPrincipal.setBackground(new Color(240, 255, 255));
		painelPrincipal.setBorder(new EmptyBorder(0, 0, 0, 0));

		setContentPane(painelPrincipal);
		SpringLayout sl_painelPrincipal = new SpringLayout();
		painelPrincipal.setLayout(sl_painelPrincipal);

		

		JScrollPane scrollPane = new JScrollPane();
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, scrollPane, 383, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, scrollPane, -10, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, scrollPane, -10, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(scrollPane);


		JLabel labelNome = new JLabel("Nome: ");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, scrollPane, 0, SpringLayout.NORTH, labelNome);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, labelNome, 77, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, labelNome, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, labelNome, 102, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, labelNome, 75, SpringLayout.WEST, painelPrincipal);
		labelNome.setForeground(Color.BLACK);
		labelNome.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 20));
		painelPrincipal.add(labelNome);

		JTextField caixaNome = new JTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaNome, 108, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaNome, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaNome, 359, SpringLayout.WEST, painelPrincipal);
		painelPrincipal.add(caixaNome);
		caixaNome.setColumns(10);

		JComboBox comboArea = new JComboBox();
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, comboArea, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, comboArea, 202, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, comboArea, 182, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, comboArea, -190, SpringLayout.WEST, scrollPane);
		painelPrincipal.add(comboArea);
		comboArea.addItem("Selecione");
		comboArea.addItem("Constru��o Urbana");
		comboArea.addItem("Estrutura e funda�ao");
		comboArea.addItem("Infraestrutura e Transporte");
		comboArea.addItem("Ger�ncia de recursos prediais");
		comboArea.addItem("Saneamento");
		comboArea.addItem("Hidr�ulica e Recursos H�dricos");

		JLabel lblCpf = new JLabel("CPF:");
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblCpf, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblCpf, 62, SpringLayout.WEST, painelPrincipal);
		lblCpf.setForeground(Color.BLACK);
		lblCpf.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 20));
		painelPrincipal.add(lblCpf);
		
		MaskFormatter mascaraCPF = new MaskFormatter();
		
		try {
		 mascaraCPF = new MaskFormatter("###.###.###-##");
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JFormattedTextField caixaCPF = new JFormattedTextField(mascaraCPF);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaCPF, 3, SpringLayout.NORTH, lblCpf);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaCPF, 6, SpringLayout.EAST, lblCpf);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaCPF, 3, SpringLayout.SOUTH, lblCpf);
		painelPrincipal.add(caixaCPF);

		JLabel labelRG = new JLabel("RG:");
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaCPF, -6, SpringLayout.WEST, labelRG);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, labelRG, 221, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, labelRG, 170, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, labelRG, 20, SpringLayout.NORTH, lblCpf);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, labelRG, 0, SpringLayout.NORTH, lblCpf);
		labelRG.setForeground(Color.BLACK);
		labelRG.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 20));
		painelPrincipal.add(labelRG);


		MaskFormatter mascaraRG = new MaskFormatter();
		
		try {
			mascaraRG = new MaskFormatter("#.###.###");
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		JFormattedTextField caixaRG = new JFormattedTextField(mascaraRG);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaRG, 6, SpringLayout.EAST, labelRG);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaRG, 0, SpringLayout.NORTH, caixaCPF);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaRG, 0, SpringLayout.SOUTH, caixaCPF);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaRG, -64, SpringLayout.WEST, scrollPane);
		painelPrincipal.add(caixaRG);

		JLabel labelCidade = new JLabel("Cidade:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, labelCidade, 21, SpringLayout.SOUTH, comboArea);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, labelCidade, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, labelCidade, 46, SpringLayout.SOUTH, comboArea);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, labelCidade, 102, SpringLayout.WEST, painelPrincipal);
		labelCidade.setForeground(Color.BLACK);
		labelCidade.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 20));
		painelPrincipal.add(labelCidade);

		JTextField caixaCidade = new JTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaCidade, 6, SpringLayout.SOUTH, labelCidade);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaCidade, 0, SpringLayout.WEST, labelNome);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaCidade, 169, SpringLayout.WEST, labelNome);
		painelPrincipal.add(caixaCidade);
		caixaCidade.setColumns(10);

		JLabel lblUf = new JLabel("UF:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblUf, 92, SpringLayout.SOUTH, caixaNome);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblUf, 194, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblUf, -138, SpringLayout.WEST, scrollPane);
		lblUf.setForeground(Color.BLACK);
		lblUf.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 20));
		painelPrincipal.add(lblUf);

		JComboBox comboUF = new JComboBox();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, comboUF, 7, SpringLayout.SOUTH, lblUf);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, comboUF, 0, SpringLayout.WEST, lblUf);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, comboUF, 97, SpringLayout.WEST, lblUf);
		painelPrincipal.add(comboUF);
		comboUF.addItem("Selecione");
		comboUF.addItem("AC");
		comboUF.addItem("AL");
		comboUF.addItem("AP");
		comboUF.addItem("AM");
		comboUF.addItem("BA");
		comboUF.addItem("CE");
		comboUF.addItem("DF");
		comboUF.addItem("ES");
		comboUF.addItem("GO");
		comboUF.addItem("MA");
		comboUF.addItem("MT");
		comboUF.addItem("MS");
		comboUF.addItem("PA");
		comboUF.addItem("PB");
		comboUF.addItem("PR");
		comboUF.addItem("PE");
		comboUF.addItem("RJ");
		comboUF.addItem("RN");
		comboUF.addItem("RS");
		comboUF.addItem("RO");
		comboUF.addItem("RR");
		comboUF.addItem("SC");
		comboUF.addItem("SP");
		comboUF.addItem("SE");
		comboUF.addItem("TO");

		

		JLabel labelfone = new JLabel("Telefone:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, labelfone, 18, SpringLayout.SOUTH, caixaCPF);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, labelfone, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, labelfone, 38, SpringLayout.SOUTH, caixaCPF);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, labelfone, 102, SpringLayout.WEST, painelPrincipal);
		labelfone.setForeground(Color.BLACK);
		labelfone.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 20));
		painelPrincipal.add(labelfone);

		MaskFormatter mascaraFone = new MaskFormatter();
		
		try {
			mascaraFone = new MaskFormatter("(##) #####.####");
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		JFormattedTextField caixaFone = new JFormattedTextField(mascaraFone);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaFone, 2, SpringLayout.NORTH, labelfone);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaFone, 6, SpringLayout.EAST, labelfone);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaFone, 24, SpringLayout.NORTH, labelfone);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaFone, 147, SpringLayout.EAST, labelfone);
		painelPrincipal.add(caixaFone);
		caixaFone.setColumns(10);

		JLabel labelEmail = new JLabel("Endere\u00E7o de E-mail");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, labelEmail, 15, SpringLayout.SOUTH, caixaCidade);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, labelEmail, 0, SpringLayout.WEST, labelNome);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, labelEmail, 44, SpringLayout.SOUTH, caixaCidade);
		labelEmail.setForeground(Color.BLACK);
		labelEmail.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 18));
		painelPrincipal.add(labelEmail);

		JTextField caixaEmail = new JTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaCidade, -50, SpringLayout.NORTH, caixaEmail);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, comboUF, -50, SpringLayout.NORTH, caixaEmail);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblCpf, 30, SpringLayout.SOUTH, caixaEmail);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblCpf, 50, SpringLayout.SOUTH, caixaEmail);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaEmail, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaEmail, -24, SpringLayout.WEST, scrollPane);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaEmail, 324, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaEmail, 346, SpringLayout.NORTH, painelPrincipal);
		caixaEmail.setColumns(10);
		painelPrincipal.add(caixaEmail);

		JLabel labelDescricao = new JLabel("Descri\u00E7\u00E3o");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, labelDescricao, 19, SpringLayout.SOUTH, caixaFone);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, labelDescricao, 0, SpringLayout.WEST, labelNome);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, labelDescricao, 110, SpringLayout.WEST, labelNome);
		labelDescricao.setForeground(Color.BLACK);
		labelDescricao.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 20));
		painelPrincipal.add(labelDescricao);

		JTextField caixaDescricao = new JTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaDescricao, 6, SpringLayout.SOUTH, labelDescricao);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaDescricao, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaDescricao, 26, SpringLayout.SOUTH, labelDescricao);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaDescricao, 359, SpringLayout.WEST, painelPrincipal);
		caixaDescricao.setHorizontalAlignment(SwingConstants.LEFT);
		painelPrincipal.add(caixaDescricao);
		caixaDescricao.setColumns(10);
		
		tabelaEngenheiros = new JTable();
		tabelaEngenheiros.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				String id, nome, area, cpf, rg, cidade, uf, fone, email, resumo;
				
				int numeroLinha = 0;
				numeroLinha = tabelaEngenheiros.getSelectedRow();

				id = modelo.getValueAt(numeroLinha, 0).toString();
				nome = modelo.getValueAt(numeroLinha, 1).toString();
				area = modelo.getValueAt(numeroLinha, 2).toString();
				cpf = modelo.getValueAt(numeroLinha, 3).toString();
				rg = modelo.getValueAt(numeroLinha, 4).toString();
				cidade = modelo.getValueAt(numeroLinha, 5).toString();
				uf = modelo.getValueAt(numeroLinha, 6).toString();
				fone = modelo.getValueAt(numeroLinha, 7).toString();
				email = modelo.getValueAt(numeroLinha, 8).toString();
				resumo = modelo.getValueAt(numeroLinha, 9).toString();
				
				id_eng = id;
				caixaNome.setText(nome);
				caixaCPF.setText(cpf);
				caixaRG.setText(rg);
				caixaCidade.setText(cidade);
				caixaFone.setText(fone);
				caixaEmail.setText(email);
				caixaDescricao.setText(resumo);
				comboArea.setSelectedItem(area);
				comboUF.setSelectedItem(uf);

			}
		});
		scrollPane.setViewportView(tabelaEngenheiros);

		Object[] titulos = { "ID", " NOME ", " �REAS ", " CPF ", " RG ", " CIDADE ", "UF", " TELEFONE ", "E-MAIL",
				"DECRI��O DO FUNCIONARIO    " };
		modelo.setColumnIdentifiers(titulos);
		
		Object[] linhas = new Object[10];

		
		tabelaEngenheiros.setModel(modelo);
		
		JLabel lblNewLabel_1 = new JLabel("\u00C1rea de atua\u00E7\u00E3o:");
		lblNewLabel_1.setForeground(Color.BLACK);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaNome, -18, SpringLayout.NORTH, lblNewLabel_1);
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 146, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblNewLabel_1, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblNewLabel_1, 176, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblNewLabel_1, 174, SpringLayout.WEST, painelPrincipal);
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.BOLD, 18));
		painelPrincipal.add(lblNewLabel_1);
		
		JPanel panelTopo2 = new JPanel();
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, panelTopo2, 5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, panelTopo2, 60, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, panelTopo2, 413, SpringLayout.WEST, painelPrincipal);
		panelTopo2.setBackground(new Color(32, 178, 170));
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, panelTopo2, 10, SpringLayout.NORTH, painelPrincipal);
		painelPrincipal.add(panelTopo2);
		SpringLayout sl_panelTopo2 = new SpringLayout();
		panelTopo2.setLayout(sl_panelTopo2);
		
		JLabel lblNewLabel_2 = new JLabel("Gerenciamento de  Engenheiro");
		sl_panelTopo2.putConstraint(SpringLayout.SOUTH, lblNewLabel_2, -5, SpringLayout.SOUTH, panelTopo2);
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		sl_panelTopo2.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 10, SpringLayout.NORTH, panelTopo2);
		sl_panelTopo2.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, panelTopo2);
		sl_panelTopo2.putConstraint(SpringLayout.EAST, lblNewLabel_2, 0, SpringLayout.EAST, panelTopo2);
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD, 25));
		panelTopo2.add(lblNewLabel_2);
		
		JPanel panelTopo1 = new JPanel();
		panelTopo1.setBackground(new Color(0, 128, 128));
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, panelTopo1, 5, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, panelTopo1, 0, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, panelTopo1, 65, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, panelTopo1, 0, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(panelTopo1);
		SpringLayout sl_panelTopo1 = new SpringLayout();
		panelTopo1.setLayout(sl_panelTopo1);
		
		JButton btnNewButton_1 = new JButton("FECHA");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		sl_panelTopo1.putConstraint(SpringLayout.WEST, btnNewButton_1, -100, SpringLayout.EAST, panelTopo1);
		sl_panelTopo1.putConstraint(SpringLayout.EAST, btnNewButton_1, -10, SpringLayout.EAST, panelTopo1);
		btnNewButton_1.setBackground(new Color(220, 20, 60));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		sl_panelTopo1.putConstraint(SpringLayout.NORTH, btnNewButton_1, 10, SpringLayout.NORTH, panelTopo1);
		panelTopo1.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Cadastrar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/*
				 * id_engenheiro serial primary key not null, nome varchar(250) not null, area
				 * varchar(100) not null, cpf varchar(20) not null, rg varchar(20) not null,
				 * cidade varchar(30) not null, uf varchar(2) not null, fone varchar(20) not
				 * null, email varchar(100) not null, resumo varchar(750)
				 */

				String nome, area, cpf, rg, cidade, uf, fone, email, resumo;

				nome = caixaNome.getText();
				cpf = caixaCPF.getText();
				rg = caixaRG.getText();
				cidade = caixaCidade.getText();
				fone = caixaFone.getText();
				email = caixaEmail.getText();
				resumo = caixaDescricao.getText();

				area = comboArea.getSelectedItem().toString();
				uf = comboUF.getSelectedItem().toString();
				String sql = "insert into tb_engenheiro (nome_completo, area, cpf, rg, cidade, uf, fone,email, resumo) values (?, ? , ? , ? , ? ,?, ?, ?, ?)";

				Conexao novaConexao = new Conexao();
				Connection conectar = novaConexao.getConexao();
				PreparedStatement preparar = null;
				ResultSet resultado = null;

				try {
					preparar = conectar.prepareStatement(sql);
					preparar.setString(1, nome);
					preparar.setString(2, area);
					preparar.setString(3, cpf);
					preparar.setString(4, rg);
					preparar.setString(5, cidade);
					preparar.setString(6, uf);
					preparar.setString(7, fone);
					preparar.setString(8, email);
					preparar.setString(9, resumo);

					preparar.execute();
					JOptionPane.showMessageDialog(null, "Cadastrado com sucesso");
					
					dispose();
					
					TelaDeEngenheiros t1 = new TelaDeEngenheiros();
					t1.setVisible(true);
					t1.setLocationRelativeTo(null);

				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Falha ao cadastrar!");
					System.err.println(e2.getMessage());
				}
			}
		});
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, btnNewButton, -140, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, btnNewButton, 333, SpringLayout.WEST, painelPrincipal);
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(46, 139, 87));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, btnNewButton, 50, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, btnNewButton, -100, SpringLayout.SOUTH, painelPrincipal);
		painelPrincipal.add(btnNewButton);
		
		JButton btnAltetar = new JButton("Alterar");
		btnAltetar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/*
				 * id_engenheiro serial primary key not null, nome varchar(250) not null, area
				 * varchar(100) not null, cpf varchar(20) not null, rg varchar(20) not null,
				 * cidade varchar(30) not null, uf varchar(2) not null, fone varchar(20) not
				 * null, email varchar(100) not null, resumo varchar(750)
				 */
				
				String id, nome, area, cpf, rg, cidade, uf, fone, email, resumo;
				
				id = id_eng;
				nome = caixaNome.getText();
				cpf = caixaCPF.getText();
				rg = caixaRG.getText();
				cidade = caixaCidade.getText();
				fone = caixaFone.getText();
				email = caixaEmail.getText();
				resumo = caixaDescricao.getText();

				area = comboArea.getSelectedItem().toString();
				uf = comboUF.getSelectedItem().toString();
				//Passo 1 - Comando SQL
				
				String sql = "UPDATE tb_engenheiro SET nome_completo=?,"
						+ " area=?, cpf=?, rg=?, cidade=?, uf=?, fone=?, email=?, resumo=?"
						+ " WHERE id_engenheiro=?";			
				
				//Passo 2 - Preparar a conexão
				Conexao novaConexao = new Conexao();
				Connection conectar = novaConexao.getConexao();
				PreparedStatement preparar = null;
				ResultSet resultados = null;
				
				//Passo 3 - Tentar executar o SQL
				try {
					preparar = conectar.prepareStatement(sql);
					preparar.setString(1, nome);
					preparar.setString(2, area);
					preparar.setString(3, cpf);
					preparar.setString(4, rg);
					preparar.setString(5, cidade);
					preparar.setString(6, uf);
					preparar.setString(7, fone);
					preparar.setString(8, email);
					preparar.setString(9, resumo);
					preparar.setString(10, id);



					preparar.execute();
					JOptionPane.showMessageDialog(null, 
							"Atualizado com sucesso");
					dispose();
					TelaDeEngenheiros t1 = new TelaDeEngenheiros();
					t1.setVisible(true);
					t1.setLocationRelativeTo(null);
					
				}catch(Exception erro) {
					System.err.println("Falha ao atualizar");
					System.err.println(erro.getMessage());
				}
			}
		});
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, btnAltetar, -93, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, btnAltetar, 50, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, btnAltetar, -54, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, btnAltetar, 333, SpringLayout.WEST, painelPrincipal);
		btnAltetar.setForeground(Color.WHITE);
		btnAltetar.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		btnAltetar.setBackground(new Color(46, 139, 87));
		painelPrincipal.add(btnAltetar);
		
		JButton btnExcluir_1 = new JButton("Excluir");
		btnExcluir_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String id = id_eng;
				
				String sql = "delete from tb_engenheiro "
						+ "where id_engenheiro=?";
				
				Conexao novaConexao = new Conexao();
				Connection conectar = novaConexao.getConexao();
				PreparedStatement preparar = null;
				ResultSet resultado = null;

				try {
					int opcaoEscolhida;
					opcaoEscolhida = JOptionPane.showConfirmDialog(null, "Você tem certeza que deseja excluir? ");
					
					if(opcaoEscolhida == 0 ) {
						preparar = conectar.prepareStatement(sql);
						preparar.setString(1, id);
						preparar.execute();
						JOptionPane.showMessageDialog(null, "Cadastrado deletado com sucesso");
						dispose();
						
						TelaDeEngenheiros t1 = new TelaDeEngenheiros();
						t1.setVisible(true);
						t1.setLocationRelativeTo(null);
					}
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Falha ao deletar!");
					System.err.println(e2.getMessage());
				}
				
			}
		});
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, btnExcluir_1, -47, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, btnExcluir_1, 50, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, btnExcluir_1, -10, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, btnExcluir_1, 333, SpringLayout.WEST, painelPrincipal);
		btnExcluir_1.setForeground(Color.WHITE);
		btnExcluir_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		btnExcluir_1.setBackground(new Color(46, 139, 87));
		painelPrincipal.add(btnExcluir_1);
		String sql = "SELECT * FROM tb_engenheiro";
		Conexao novaConexao = new Conexao();
		Connection conectar = novaConexao.getConexao();
		PreparedStatement preparar = null;
		ResultSet resultado = null;

		try {

			preparar = conectar.prepareStatement(sql);
			resultado = preparar.executeQuery();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Falha ao Conultar");
			System.err.println(e.getMessage());
		}

		try {

			while (resultado.next()) {
				linhas[0] = resultado.getString("id_engenheiro");
				linhas[1] = resultado.getString("nome_completo");
				linhas[2] = resultado.getString("area");
				linhas[3] = resultado.getString("cpf");
				linhas[4] = resultado.getString("rg");
				linhas[5] = resultado.getString("cidade");
				linhas[6] = resultado.getString("uf");
				linhas[7] = resultado.getString("fone");
				linhas[8] = resultado.getString("email");
				linhas[9] = resultado.getString("resumo");

				modelo.addRow(linhas);
			}
		} catch (Exception e) {
			System.err.println("Falha ao consultar tabela");
			System.err.println(e.getMessage());
		}

	}
}
