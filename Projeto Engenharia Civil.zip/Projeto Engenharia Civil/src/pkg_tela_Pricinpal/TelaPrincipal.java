package pkg_tela_Pricinpal;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pkg_telas_Engenheiros.TelaDeEngenheiros;
import pkg_telas_Engenheiros.telaEngenheiros;
import pkg_telas_projetos.TelaProjetos;
import pkg_telas_projetos.TelaTabelaProjetos;
import pkg_telas_usuarios.GerenciamentoUsuario;
import pkg_telas_usuarios.TelaUsuario;

import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.SpringLayout;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class TelaPrincipal extends JFrame {

	private JPanel painelPrincipal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public TelaPrincipal() {
		setTitle("ECO Civil - Painel Principal");
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelaPrincipal.class.getResource("/pkg_imagens/ECO Civil (1).png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 801, 565);
		painelPrincipal = new JPanel();
		painelPrincipal.setBackground(new Color(102, 205, 170));
		painelPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(painelPrincipal);
		SpringLayout sl_painelPrincipal = new SpringLayout();
		painelPrincipal.setLayout(sl_painelPrincipal);
		
		JPanel painelEsquerdo = new JPanel();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, painelEsquerdo, 55, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, painelEsquerdo, 550, SpringLayout.WEST, painelPrincipal);
		painelEsquerdo.setBackground(new Color(240, 255, 240));
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, painelEsquerdo, -10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, painelEsquerdo, 5, SpringLayout.SOUTH, painelPrincipal);
		painelPrincipal.add(painelEsquerdo);
		SpringLayout sl_painelEsquerdo = new SpringLayout();
		painelEsquerdo.setLayout(sl_painelEsquerdo);
		
		painelEsquerdo.setBackground(new Color(171, 237, 217));
			
		
		JButton imagem2 = new JButton("GERENCIAR USUARIOS");
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, imagem2, 45, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, imagem2, 50, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, imagem2, 159, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, imagem2, -50, SpringLayout.EAST, painelEsquerdo);
		imagem2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				imagem2.setBackground(new Color(26, 196, 196));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				imagem2.setBackground(new Color(0, 139, 139));
				
			}
		});
		imagem2.setForeground(new Color(255, 255, 255));
		imagem2.setFont(new Font("Footlight MT Light", Font.BOLD, 28));
		imagem2.setBackground(new Color(0, 139, 139));
		imagem2.setBorder(null);
		imagem2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				GerenciamentoUsuario t1 = new GerenciamentoUsuario();
				t1.setVisible(true);
				t1.setLocationRelativeTo(null);

				
			}
		});
		painelEsquerdo.add(imagem2);
		
		JButton imagem3 = new JButton("GERENCIAR ENGENHEIROS");
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, imagem3, 29, SpringLayout.SOUTH, imagem2);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, imagem3, 0, SpringLayout.WEST, imagem2);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, imagem3, -50, SpringLayout.EAST, painelEsquerdo);
		imagem3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				imagem3.setBackground(new Color(26, 196, 196));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				imagem3.setBackground(new Color(0, 139, 139));
				
			}
		});
		imagem3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaDeEngenheiros t1 = new TelaDeEngenheiros();
				t1.setVisible(true);
				t1.setLocationRelativeTo(null);
				
				
			}
		});
		imagem3.setForeground(new Color(255, 255, 255));
		imagem3.setFont(new Font("Footlight MT Light", Font.BOLD, 28));
		imagem3.setBackground(new Color(0, 139, 139));
		imagem3.setBorder(null);
		painelEsquerdo.add(imagem3);
		
		JButton imagem4 = new JButton("PROJETOS");
		imagem4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaProjetos t1 = new TelaProjetos();
				t1.setVisible(true);
				t1.setLocationRelativeTo(null);
				
				
			}
		});
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, imagem4, 438, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.SOUTH, imagem3, -28, SpringLayout.NORTH, imagem4);
		sl_painelEsquerdo.putConstraint(SpringLayout.NORTH, imagem4, 330, SpringLayout.NORTH, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.WEST, imagem4, 50, SpringLayout.WEST, painelEsquerdo);
		sl_painelEsquerdo.putConstraint(SpringLayout.EAST, imagem4, -50, SpringLayout.EAST, painelEsquerdo);
		imagem4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				imagem4.setBackground(new Color(26, 196, 196));
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				imagem4.setBackground(new Color(0, 139, 139));
				
			}
		});
		imagem4.setBorder(null);
		imagem4.setBackground(new Color(0, 139, 139));
		imagem4.setForeground(new Color(255, 255, 255));
		imagem4.setFont(new Font("Footlight MT Light", Font.BOLD, 29));
		painelEsquerdo.add(imagem4);
		
		JPanel painelTopo = new JPanel();
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, painelTopo, 55, SpringLayout.NORTH, painelPrincipal);
		painelTopo.setBackground(new Color(0, 139, 139));
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, painelTopo, -5, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, painelTopo, -5, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, painelTopo, 5, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(painelTopo);
		
		JPanel panel = new JPanel();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, panel, -45, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, panel, 385, SpringLayout.WEST, painelEsquerdo);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, panel, 0, SpringLayout.SOUTH, painelPrincipal);
		panel.setBackground(new Color(0, 128, 128));
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, panel, 5, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(panel);
		
		JLabel imagem = new JLabel("");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, imagem, 60, SpringLayout.NORTH, painelTopo);
		SpringLayout sl_painelTopo = new SpringLayout();
		painelTopo.setLayout(sl_painelTopo);
		
		JButton btnNewButton = new JButton("Usuarios");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaUsuario t1 = new TelaUsuario();
				t1.setVisible(true);
				t1.setLocationRelativeTo(null);
			}
		});
		sl_painelTopo.putConstraint(SpringLayout.NORTH, btnNewButton, 10, SpringLayout.NORTH, painelTopo);
		sl_painelTopo.putConstraint(SpringLayout.WEST, btnNewButton, 10, SpringLayout.WEST, painelTopo);
		sl_painelTopo.putConstraint(SpringLayout.SOUTH, btnNewButton, 50, SpringLayout.NORTH, painelTopo);
		btnNewButton.setBackground(new Color(60, 179, 113));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		painelTopo.add(btnNewButton);
		
		JButton btnEngenheiros = new JButton("Engenheiros");
		btnEngenheiros.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				telaEngenheiros t1 = new telaEngenheiros();
				t1.setVisible(true);
				t1.setLocationRelativeTo(null);
			}
		});
		sl_painelTopo.putConstraint(SpringLayout.NORTH, btnEngenheiros, 0, SpringLayout.NORTH, btnNewButton);
		sl_painelTopo.putConstraint(SpringLayout.WEST, btnEngenheiros, 6, SpringLayout.EAST, btnNewButton);
		sl_painelTopo.putConstraint(SpringLayout.SOUTH, btnEngenheiros, 40, SpringLayout.NORTH, btnNewButton);
		btnEngenheiros.setForeground(Color.WHITE);
		btnEngenheiros.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnEngenheiros.setBackground(new Color(60, 179, 113));
		painelTopo.add(btnEngenheiros);
		
		JButton btnProjetos = new JButton("Projetos");
		btnProjetos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaTabelaProjetos t1 = new TelaTabelaProjetos();
				t1.setVisible(true);
				t1.setLocationRelativeTo(null);
			}
		});
		sl_painelTopo.putConstraint(SpringLayout.NORTH, btnProjetos, 0, SpringLayout.NORTH, btnNewButton);
		sl_painelTopo.putConstraint(SpringLayout.WEST, btnProjetos, 6, SpringLayout.EAST, btnEngenheiros);
		sl_painelTopo.putConstraint(SpringLayout.SOUTH, btnProjetos, 40, SpringLayout.NORTH, btnNewButton);
		btnProjetos.setForeground(Color.WHITE);
		btnProjetos.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnProjetos.setBackground(new Color(60, 179, 113));
		painelTopo.add(btnProjetos);
		
		JButton btnNewButton_3 = new JButton("FECHA");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		sl_painelTopo.putConstraint(SpringLayout.NORTH, btnNewButton_3, 0, SpringLayout.NORTH, btnNewButton);
		sl_painelTopo.putConstraint(SpringLayout.EAST, btnNewButton_3, -10, SpringLayout.EAST, painelTopo);
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_3.setBackground(new Color(220, 20, 60));
		painelTopo.add(btnNewButton_3);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, imagem, 410, SpringLayout.WEST, painelEsquerdo);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, imagem, -44, SpringLayout.SOUTH, panel);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, imagem, 0, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(imagem);
		
        ImageIcon foto = new ImageIcon (TelaPrincipal.class.getResource("/pkg_imagens/ECO Civil.png"));
	
    	imagem.setIcon(new ImageIcon(foto.getImage().getScaledInstance(1500, 700,Image.SCALE_DEFAULT)));
    				
	}
}
