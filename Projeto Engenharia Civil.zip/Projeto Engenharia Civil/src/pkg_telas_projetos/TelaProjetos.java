package pkg_telas_projetos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;


import pkg_banco_de_dados.Conexao;
import pkg_banco_de_dados.ConsultarID;

import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Toolkit;
import javax.swing.JMenuBar;

public class TelaProjetos extends JFrame {

	private JPanel painelPrincipal;
	private JTextField caixaNome;
	private JTextField caixaDataInicio;
	private JTextField caixaDataFinal;
	private JTextField caixaPreco;
	private JTable tabela1;

	DefaultTableModel modelo = new DefaultTableModel();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaProjetos frame = new TelaProjetos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaProjetos() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelaProjetos.class.getResource("/pkg_imagens/logo_.jpg")));
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setBackground(new Color(32, 178, 170));
		setTitle("ECO Civil - Gerenciamento de  projetos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1103, 711);
		painelPrincipal = new JPanel();
		painelPrincipal.setBackground(new Color(240, 255, 255));
		painelPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(painelPrincipal);
		SpringLayout sl_painelPrincipal = new SpringLayout();
		painelPrincipal.setLayout(sl_painelPrincipal);
		
		JPanel painelTopo = new JPanel();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, painelTopo, 11, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, painelTopo, 0, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, painelTopo, 150, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, painelTopo, -10, SpringLayout.EAST, painelPrincipal);
		painelTopo.setBackground(new Color(0, 128, 128));
		painelPrincipal.add(painelTopo);
		SpringLayout sl_painelTopo = new SpringLayout();
		painelTopo.setLayout(sl_painelTopo);
		
		JLabel lblNewLabel_7 = new JLabel("Gerenciamento de projetos");
		sl_painelTopo.putConstraint(SpringLayout.NORTH, lblNewLabel_7, 11, SpringLayout.NORTH, painelTopo);
		sl_painelTopo.putConstraint(SpringLayout.WEST, lblNewLabel_7, 10, SpringLayout.WEST, painelTopo);
		sl_painelTopo.putConstraint(SpringLayout.SOUTH, lblNewLabel_7, 64, SpringLayout.NORTH, painelTopo);
		sl_painelTopo.putConstraint(SpringLayout.EAST, lblNewLabel_7, 433, SpringLayout.WEST, painelTopo);
		lblNewLabel_7.setForeground(new Color(255, 255, 255));
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 30));
		painelTopo.add(lblNewLabel_7);
		
		JLabel lblNewLabel = new JLabel("Nome:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblNewLabel, 169, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblNewLabel, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblNewLabel, 199, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblNewLabel, 86, SpringLayout.WEST, painelPrincipal);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		painelPrincipal.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tipo:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 251, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblNewLabel_1, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblNewLabel_1, 281, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblNewLabel_1, 76, SpringLayout.WEST, painelPrincipal);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		painelPrincipal.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Data de inicializa\u00E7\u00E3o:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 329, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblNewLabel_2, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblNewLabel_2, 359, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblNewLabel_2, 213, SpringLayout.WEST, painelPrincipal);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		painelPrincipal.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("ID:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblNewLabel_3, 159, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblNewLabel_3, 217, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblNewLabel_3, 189, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblNewLabel_3, 263, SpringLayout.WEST, painelPrincipal);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		painelPrincipal.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Data de finaliza\u00E7\u00E3o:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblNewLabel_4, 405, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblNewLabel_4, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblNewLabel_4, 435, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblNewLabel_4, 213, SpringLayout.WEST, painelPrincipal);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		painelPrincipal.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Custo do projeto:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblNewLabel_5, 503, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblNewLabel_5, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblNewLabel_5, 533, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblNewLabel_5, 194, SpringLayout.WEST, painelPrincipal);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 16));
		painelPrincipal.add(lblNewLabel_5);
		
		JFormattedTextField caixaID = new JFormattedTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaID, 166, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaID, 258, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaID, 353, SpringLayout.WEST, painelPrincipal);
		caixaID.setFont(new Font("Tahoma", Font.PLAIN, 14));
		caixaID.setEnabled(false);
		painelPrincipal.add(caixaID);
		
		caixaNome = new JTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaNome, 210, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaNome, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaNome, 240, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaNome, 353, SpringLayout.WEST, painelPrincipal);
		caixaNome.setFont(new Font("Tahoma", Font.PLAIN, 14));
		painelPrincipal.add(caixaNome);
		caixaNome.setColumns(10);
		
		JComboBox comboTipo = new JComboBox();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, comboTipo, 288, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, comboTipo, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, comboTipo, 318, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, comboTipo, 353, SpringLayout.WEST, painelPrincipal);
		comboTipo.setFont(new Font("Tahoma", Font.PLAIN, 14));
		painelPrincipal.add(comboTipo);
		comboTipo.addItem("Selecione");
		comboTipo.addItem("Arquitet�nico");
		comboTipo.addItem("Estrutural");
		comboTipo.addItem("El�trico");
		comboTipo.addItem("Combate � inc�ndio");
		
		
		
		
		caixaDataInicio = new JTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaDataInicio, 364, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaDataInicio, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaDataInicio, 394, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaDataInicio, 353, SpringLayout.WEST, painelPrincipal);
		caixaDataInicio.setFont(new Font("Tahoma", Font.PLAIN, 14));
		painelPrincipal.add(caixaDataInicio);
		caixaDataInicio.setColumns(10);
		
		caixaDataFinal = new JTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaDataFinal, 446, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaDataFinal, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaDataFinal, 476, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaDataFinal, 353, SpringLayout.WEST, painelPrincipal);
		caixaDataFinal.setFont(new Font("Tahoma", Font.PLAIN, 14));
		painelPrincipal.add(caixaDataFinal);
		caixaDataFinal.setColumns(10);
		
		caixaPreco = new JTextField();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, caixaPreco, 544, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, caixaPreco, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, caixaPreco, 574, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, caixaPreco, 353, SpringLayout.WEST, painelPrincipal);
		caixaPreco.setFont(new Font("Tahoma", Font.PLAIN, 14));
		painelPrincipal.add(caixaPreco);
		caixaPreco.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Engenheiro:");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, lblNewLabel_6, 590, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, lblNewLabel_6, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, lblNewLabel_6, 620, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, lblNewLabel_6, 147, SpringLayout.WEST, painelPrincipal);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		painelPrincipal.add(lblNewLabel_6);
		
		JComboBox comboEngenheiro = new JComboBox();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, comboEngenheiro, 631, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, comboEngenheiro, 10, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, comboEngenheiro, 663, SpringLayout.NORTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, comboEngenheiro, 353, SpringLayout.WEST, painelPrincipal);
		comboEngenheiro.setFont(new Font("Tahoma", Font.PLAIN, 14));
		painelPrincipal.add(comboEngenheiro);
		comboEngenheiro.addItem("Selecionar");
		String sql2 = "SELECT * FROM tb_engenheiro";
		
		Conexao novaConexao2 = new Conexao();
		Connection conectar2 = novaConexao2.getConexao();
		PreparedStatement preparar2 = null;
		ResultSet resultados2 = null;
		
		try {
			preparar2 = conectar2.prepareStatement(sql2);
			resultados2 = preparar2.executeQuery();
			while(resultados2.next()) {
				String nome = resultados2.getString("nome_completo");
				
				comboEngenheiro.addItem(nome);
			}
			
			
		}catch(Exception erro) {
			JOptionPane.showMessageDialog(null, "Falha ao consultar engenheiros");
			System.out.println(erro.getMessage());
		}
		
		
		
		JButton btnCadastrar = new JButton("Cadastrar");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, btnCadastrar, -47, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, btnCadastrar, 466, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, btnCadastrar, -5, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, btnCadastrar, 603, SpringLayout.WEST, painelPrincipal);
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nome, tipo, dataInicio, dataFinal, valor, 
				engenheiro;
				
				nome = caixaNome.getText();
				tipo = comboTipo.getSelectedItem().toString();
				dataInicio = caixaDataInicio.getText();
				dataFinal = caixaDataFinal.getText();
				valor = caixaPreco.getText();
				engenheiro = comboEngenheiro.getSelectedItem().toString();
				
				ConsultarID consulta = new ConsultarID();
				engenheiro = consulta.fazerConsulta(engenheiro);
				
				
				//Passo 1 - Comando SQL
				String sql = "INSERT INTO tb_projetos "
						+ " (nome_projeto, tipo, data_inicializar, data_finalizar, "
						+ "preco, fk_id_engenheiro) values "
						+ " (?, ?, ?, ?, ?, ?)";
				//Passo 2 - Preparar conex�o
				Conexao novaConexao = new Conexao();
				Connection conectar = novaConexao.getConexao();
				PreparedStatement preparar = null;
				ResultSet resultados = null;
				
				//Passo 3 - terntar executar o sql
				try {
					preparar = conectar.prepareStatement(sql);
					//Substituir as interroga��es
					preparar.setString(1, nome);
					preparar.setString(2, tipo);
					preparar.setString(3, dataInicio);
					preparar.setString(4, dataFinal);
					preparar.setString(5, valor);
					preparar.setString(6, engenheiro);
					preparar.execute();
					JOptionPane.showMessageDialog(null, "Cadastrado co sucesso!");
					
					dispose();
					TelaProjetos t1 = new TelaProjetos();
					t1.setVisible(true);
					t1.setLocationRelativeTo(null);
					
					
				}catch(Exception erro) {
					JOptionPane.showMessageDialog(null, "Falha ao cadastrar");
					System.err.println(erro.getMessage());
				}
				
			}
		});
		btnCadastrar.setFont(new Font("Tahoma", Font.BOLD, 18));
		painelPrincipal.add(btnCadastrar);
		
		JButton btnSalvar = new JButton("Salvar altera\u00E7\u00F5es");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, btnSalvar, -47, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, btnSalvar, 657, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, btnSalvar, -5, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, btnSalvar, 850, SpringLayout.WEST, painelPrincipal);
		btnSalvar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String nome, tipo, dataInicio, dataFinal, valor, 
				engenheiro, id;
				
				id = caixaID.getText();
				nome = caixaNome.getText();
				tipo =  comboTipo.getSelectedItem().toString();
				dataInicio = caixaDataInicio.getText();
				dataFinal = caixaDataFinal.getText();
				valor = caixaPreco.getText();
				engenheiro =  comboEngenheiro.getSelectedItem().toString();
				
				ConsultarID consulta = new ConsultarID();
				engenheiro = consulta.fazerConsulta(engenheiro);
				
				
				//Passo 1 - Comando SQL
				String sql = "UPDATE tb_projetos set  nome_projeto=?,"
						+ " tipo=?, data_inicializar=?, data_finalizar=?, "
						+ " preco=?, fk_id_engenheiro=? where id_projeto=?";
				
				
				//Passo 2 - Preparar conexao
				Conexao novaConexao = new Conexao();
				Connection conectar = novaConexao.getConexao();
				PreparedStatement preparar = null;
				ResultSet resultados = null;
				
				
				//Passo 3 - Tentar executar
				try {
					preparar = conectar.prepareStatement(sql);
					
					preparar.setString(1, nome);
					preparar.setString(2, tipo);
					preparar.setString(3, dataInicio);
					preparar.setString(4, dataFinal);
					preparar.setString(5, valor);
					preparar.setString(6, engenheiro);
					preparar.setString(7, id);					
					
					preparar.execute();
					JOptionPane.showMessageDialog(null,
							"Atualizado com sucesso!");
					dispose();
					TelaProjetos t1 = new TelaProjetos();
					t1.setVisible(true);
					t1.setLocationRelativeTo(null);
					
					
				}catch(Exception erro) {
					System.out.println("Falha ao atualizar");
					System.out.println(erro.getMessage());
				}
						
				
				
			}
		});
		btnSalvar.setFont(new Font("Tahoma", Font.BOLD, 18));
		painelPrincipal.add(btnSalvar);
		
		JButton btnExcluir = new JButton("Excluir");
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, btnExcluir, -47, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, btnExcluir, 938, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, btnExcluir, -5, SpringLayout.SOUTH, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, btnExcluir, 1052, SpringLayout.WEST, painelPrincipal);
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String id = caixaID.getText();
					
					//Passo 1 - Comando SQL
					String sql = "DELETE FROM tb_projetos WHERE id_projeto=?";
					
					//Passo 2 - Preparar conex�o
					
					Conexao novaConexao = new Conexao();
					Connection conectar = novaConexao.getConexao();
					PreparedStatement preparar = null;
					ResultSet resultados = null;
					
					
					//Passo 3 - Tentar excutar o sql
					try {
						int opcaoEscolhida;
						opcaoEscolhida = 
								JOptionPane.showConfirmDialog(null, 
										"Tem certeza que deseja excluir?");
						
						if(opcaoEscolhida == 0) {
							preparar = conectar.prepareStatement(sql);
							preparar.setString(1, id);
							preparar.execute();
							JOptionPane.showMessageDialog(null, 
									"Deletado com sucesso!");
							
							
							
							
							
							
							
							
							
						}
						
					}catch(Exception erro) {
						JOptionPane.showMessageDialog(null,
								"Falha ao deletar");
						System.err.println(erro.getMessage());
					}
					
				}			
				
				
				
				
				
			
		});
		btnExcluir.setFont(new Font("Tahoma", Font.BOLD, 18));
		painelPrincipal.add(btnExcluir);
		
		JScrollPane scrollPane = new JScrollPane();
		sl_painelPrincipal.putConstraint(SpringLayout.NORTH, scrollPane, 10, SpringLayout.SOUTH, painelTopo);
		
		JButton btnNewButton = new JButton("FECHA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		sl_painelTopo.putConstraint(SpringLayout.NORTH, btnNewButton, 11, SpringLayout.NORTH, painelTopo);
		sl_painelTopo.putConstraint(SpringLayout.WEST, btnNewButton, -100, SpringLayout.EAST, painelTopo);
		sl_painelTopo.putConstraint(SpringLayout.SOUTH, btnNewButton, 34, SpringLayout.NORTH, painelTopo);
		sl_painelTopo.putConstraint(SpringLayout.EAST, btnNewButton, -10, SpringLayout.EAST, painelTopo);
		btnNewButton.setBackground(new Color(220, 20, 60));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		painelTopo.add(btnNewButton);
		sl_painelPrincipal.putConstraint(SpringLayout.WEST, scrollPane, 434, SpringLayout.WEST, painelPrincipal);
		sl_painelPrincipal.putConstraint(SpringLayout.SOUTH, scrollPane, -13, SpringLayout.NORTH, btnCadastrar);
		sl_painelPrincipal.putConstraint(SpringLayout.EAST, scrollPane, -10, SpringLayout.EAST, painelPrincipal);
		painelPrincipal.add(scrollPane);
		
		tabela1 = new JTable();
		tabela1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		tabela1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int numeroLinha;
				//Esse comando descobre qual linha est� selecionada
				numeroLinha = tabela1.getSelectedRow();
				
				String id, nome, tipo, dataInicio, dataFinal, valor, engenheiro;
				
				id = modelo.getValueAt(numeroLinha,0).toString();
				nome = modelo.getValueAt(numeroLinha, 1).toString();
				tipo = modelo.getValueAt(numeroLinha, 2).toString();
				dataInicio = modelo.getValueAt(numeroLinha, 3).toString();
				dataFinal = modelo.getValueAt(numeroLinha, 4).toString();
				valor = modelo.getValueAt(numeroLinha, 5).toString();
				engenheiro = modelo.getValueAt(numeroLinha, 6).toString();
				
      			caixaID.setText(id);
				caixaNome.setText(nome);
				comboTipo.setSelectedItem(tipo);
				caixaDataInicio.setText(dataInicio);
				caixaDataFinal.setText(dataFinal);
				caixaPreco.setText(valor);
				comboEngenheiro.setSelectedItem(engenheiro);
			}
		});
		scrollPane.setViewportView(tabela1);
		
		//Definir os titulos
		Object[] titulos = {"ID", "NOME", "TIPO", 
				"DATA DE INICIALIZA��O", "DATA DE FINALIZA��O", "VALOR DO PROJETO", "ENGENHEIRO DO PROJETO"
				};
		modelo.setColumnIdentifiers(titulos);
		
		//Dividir a tabela e linhas e colunas
		Object[] linhas = new Object[7];
		
		//Aplicar o modelo no JTable
		tabela1.setModel(modelo);
		
		//Passo 1 - Comando SQL
		String sql = "SELECT * FROM tb_projetos";
		
		//Passo 2 - Preparar a conex�o
		Conexao novaConexao = new Conexao();
		Connection conectar = novaConexao.getConexao();
		PreparedStatement preparar = null;
		ResultSet resultados = null;
		
		//Passo 3 - tentar executar o SQL
		try {
			preparar = conectar.prepareStatement(sql);
			resultados = preparar.executeQuery();
			
		}catch(Exception erro) {
			JOptionPane.showMessageDialog(null, "Falha ao consultar");
			System.out.println(erro.getMessage());
		}
		
		//Passo 4 - Tentar mostrar os resultados
		try {
			while(resultados.next()) {
				linhas[0] = resultados.getString("id_projeto");
				linhas[1] = resultados.getString("nome_projeto");
				linhas[2] = resultados.getString("tipo");
				linhas[3] = resultados.getString("data_inicializar");
				linhas[4] = resultados.getString("data_finalizar");
				linhas[5] = resultados.getString("preco");
				linhas[6] = resultados.getString("nome_completo");
				modelo.addRow(linhas);
				
			}
		}catch(Exception erro) {
			JOptionPane.showMessageDialog(null, 
					"Falha ao mostrar os resultados");
			System.out.println(erro.getMessage());
		}
		
				
		scrollPane.setViewportView(tabela1);
	}
}
