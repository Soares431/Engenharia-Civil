package pkg_telas_projetos;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import pkg_banco_de_dados.Conexao;

import javax.swing.SpringLayout;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import javax.swing.JButton;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaTabelaProjetos extends JFrame {

	private JPanel contentPane;
	private JTable tabela1;

	DefaultTableModel modelo = new DefaultTableModel();
	
	TelaProjetos t1 = new TelaProjetos();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaTabelaProjetos frame = new TelaTabelaProjetos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaTabelaProjetos() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelaTabelaProjetos.class.getResource("/pkg_imagens/ECO Civil (1).png")));
		setTitle("ECO Civil - Projetos");
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 644, 402);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(175, 238, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		sl_contentPane.putConstraint(SpringLayout.NORTH, scrollPane, 50, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, scrollPane, 50, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, scrollPane, -50, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, scrollPane, -50, SpringLayout.EAST, contentPane);
		contentPane.add(scrollPane);
		
		tabela1 = new JTable();
		tabela1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		tabela1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int numeroLinha;
				//Esse comando descobre qual linha est� selecionada
				numeroLinha = tabela1.getSelectedRow();
				
				String id, nome, tipo, dataInicio, dataFinal, valor, engenheiro;
				
				id = modelo.getValueAt(numeroLinha,0).toString();
				nome = modelo.getValueAt(numeroLinha, 1).toString();
				tipo = modelo.getValueAt(numeroLinha, 2).toString();
				dataInicio = modelo.getValueAt(numeroLinha, 3).toString();
				dataFinal = modelo.getValueAt(numeroLinha, 4).toString();
				valor = modelo.getValueAt(numeroLinha, 5).toString();
				engenheiro = modelo.getValueAt(numeroLinha, 6).toString();
				
   
			}
		});
		scrollPane.setViewportView(tabela1);
		
		//Definir os titulos
		Object[] titulos = {"ID", "NOME", "TIPO", 
				"DATA DE INICIALIZA��O", "DATA DE FINALIZA��O", "VALOR DO PROJETO", "ENGENHEIRO DO PROJETO"
				};
		modelo.setColumnIdentifiers(titulos);
		
		//Dividir a tabela e linhas e colunas
		Object[] linhas = new Object[7];
		
		//Aplicar o modelo no JTable
		tabela1.setModel(modelo);
		
		//Passo 1 - Comando SQL
		String sql = "SELECT * FROM tb_projetos";
		
		//Passo 2 - Preparar a conex�o
		Conexao novaConexao = new Conexao();
		Connection conectar = novaConexao.getConexao();
		PreparedStatement preparar = null;
		ResultSet resultados = null;
		
		//Passo 3 - tentar executar o SQL
		try {
			preparar = conectar.prepareStatement(sql);
			resultados = preparar.executeQuery();
			
		}catch(Exception erro) {
			JOptionPane.showMessageDialog(null, "Falha ao consultar");
			System.out.println(erro.getMessage());
		}
		
		//Passo 4 - Tentar mostrar os resultados
		try {
			while(resultados.next()) {
				linhas[0] = resultados.getString("id_projeto");
				linhas[1] = resultados.getString("nome_projeto");
				linhas[2] = resultados.getString("tipo");
				linhas[3] = resultados.getString("data_inicializar");
				linhas[4] = resultados.getString("data_finalizar");
				linhas[5] = resultados.getString("preco");
				linhas[6] = resultados.getString("nome_completo");
				modelo.addRow(linhas);
				
			}
		}catch(Exception erro) {
			JOptionPane.showMessageDialog(null, 
					"Falha ao mostrar os resultados");
			System.out.println(erro.getMessage());
		}
		
				
		scrollPane.setViewportView(tabela1);
		
		JButton btnNewButton = new JButton("FECHA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(220, 20, 60));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnNewButton, -10, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, btnNewButton, -10, SpringLayout.EAST, contentPane);
		contentPane.add(btnNewButton);
		
		
		
		
	
		
		
	
	}
}
